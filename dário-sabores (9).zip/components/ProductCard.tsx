import React from 'react';
import { Product, SaleType } from '../types';
import { ShoppingBag, Star, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  averageRating: number;
  reviewCount: number;
  onClick: (product: Product) => void;
  onToggleFavorite: (e: React.MouseEvent, productId: string) => void;
  onRate: (e: React.MouseEvent, product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  isFavorite, 
  averageRating,
  reviewCount,
  onClick, 
  onToggleFavorite,
  onRate
}) => {
  return (
    <div 
      onClick={() => onClick(product)}
      className="group bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md dark:hover:shadow-gray-800 transition-all duration-200 cursor-pointer h-full flex flex-col active:scale-[0.98] relative"
    >
      {/* Image Section */}
      <div className="aspect-[4/3] w-full bg-gray-50 dark:bg-gray-800 relative overflow-hidden">
        {product.imageUrl ? (
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex items-center justify-center h-full text-brand-200 dark:text-gray-700">
            <ShoppingBag size={48} strokeWidth={1.5} />
          </div>
        )}
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
           <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wide text-white shadow-sm ${
            product.saleType === SaleType.DELIVERY ? 'bg-brand-600' : 'bg-gray-800 dark:bg-black'
          }`}>
            {product.saleType === SaleType.DELIVERY ? 'Encomenda' : 'Local'}
          </span>
        </div>

        {/* Favorite Button */}
        <button 
          onClick={(e) => onToggleFavorite(e, product.id)}
          className={`absolute top-2 right-2 p-2 rounded-full shadow-sm transition-all ${isFavorite ? 'bg-white text-red-500' : 'bg-black/20 text-white hover:bg-white hover:text-red-500 dark:hover:bg-gray-800'}`}
        >
           <Heart size={16} fill={isFavorite ? "currentColor" : "none"} />
        </button>
      </div>
      
      {/* Content Section */}
      <div className="p-4 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-1">
           <h3 className="text-gray-900 dark:text-white font-semibold text-lg leading-tight group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors line-clamp-1">
            {product.name}
          </h3>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
           <Star size={12} className="text-yellow-400" fill="currentColor" />
           <span className="text-xs font-bold text-gray-700 dark:text-gray-300">{averageRating > 0 ? averageRating.toFixed(1) : 'New'}</span>
           <span className="text-[10px] text-gray-400">({reviewCount})</span>
        </div>
        
        <p className="text-gray-500 dark:text-gray-400 text-xs mb-3 line-clamp-2 leading-relaxed">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-gray-50 dark:border-gray-800">
           <span className="text-lg font-bold text-brand-700 dark:text-brand-400">
              {product.price.toLocaleString('pt-PT')} <span className="text-xs text-brand-400 dark:text-gray-500 font-normal">Kz</span>
           </span>
           <div className="flex gap-2">
              <button 
                onClick={(e) => onRate(e, product)}
                className="bg-gray-50 dark:bg-gray-800 text-gray-400 dark:text-gray-500 p-2 rounded-full hover:bg-yellow-50 dark:hover:bg-gray-700 hover:text-yellow-500 transition-colors"
                title="Avaliar"
              >
                <Star size={16} />
              </button>
              <button className="bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 p-2 rounded-full group-hover:bg-brand-600 group-hover:text-white dark:group-hover:bg-brand-600 transition-colors">
                <ShoppingBag size={16} />
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};